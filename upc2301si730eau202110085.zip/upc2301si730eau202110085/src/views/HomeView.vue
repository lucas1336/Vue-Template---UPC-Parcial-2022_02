<script setup>
import AveragePerformance from '../components/analytics/AveragePerformanceComponent.vue'
</script>

<template>
  <main aria-label="Main content">
    <AveragePerformance aria-label="Average performance component" />
  </main>
</template>
